/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { jsonrpc } from "@web/core/network/rpc_service";

/**
 * Mercado Pago Checkout Integration
 */
document.addEventListener('DOMContentLoaded', function() {
    
    const checkoutForm = document.getElementById('mercadopago-checkout-form');
    
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Validar formulario
            if (!checkoutForm.checkValidity()) {
                checkoutForm.classList.add('was-validated');
                return;
            }
            
            // Obtener datos del formulario
            const partnerId = parseInt(document.getElementById('partner_id').value);
            const amount = parseFloat(document.getElementById('amount').value);
            const description = document.getElementById('description').value;
            const payerEmail = document.getElementById('payer_email').value;
            
            // Validaciones
            if (!amount || amount <= 0) {
                showAlert('Por favor ingresa un monto válido.', 'danger');
                return;
            }
            
            if (!description || description.trim() === '') {
                showAlert('Por favor ingresa una descripción del pago.', 'danger');
                return;
            }
            
            if (!payerEmail || !validateEmail(payerEmail)) {
                showAlert('Por favor ingresa un email válido.', 'danger');
                return;
            }
            
            // Deshabilitar botón y mostrar loading
            const checkoutBtn = document.getElementById('checkout-btn');
            const originalBtnText = checkoutBtn.innerHTML;
            checkoutBtn.disabled = true;
            checkoutBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>Procesando...';
            
            try {
                // Crear pago en el servidor
                const response = await fetch('/payment/mercadopago/create', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        jsonrpc: "2.0",
                        method: "call",
                        params: {
                            partner_id: partnerId,
                            amount: amount,
                            description: description,
                            payer_email: payerEmail
                        }
                    })
                });
                
                const data = await response.json();
                
                if (data.result && data.result.success) {
                    // Redirigir a Mercado Pago
                    if (data.result.init_point) {
                        showAlert('Redirigiendo a Mercado Pago...', 'success');
                        setTimeout(() => {
                            window.location.href = data.result.init_point;
                        }, 1000);
                    } else {
                        showAlert('Error: No se recibió el link de pago.', 'danger');
                        checkoutBtn.disabled = false;
                        checkoutBtn.innerHTML = originalBtnText;
                    }
                } else {
                    const errorMsg = data.result && data.result.error ? data.result.error : 'Error desconocido';
                    showAlert('Error al crear el pago: ' + errorMsg, 'danger');
                    checkoutBtn.disabled = false;
                    checkoutBtn.innerHTML = originalBtnText;
                }
                
            } catch (error) {
                console.error('Error:', error);
                showAlert('Error de conexión. Por favor intenta nuevamente.', 'danger');
                checkoutBtn.disabled = false;
                checkoutBtn.innerHTML = originalBtnText;
            }
        });
    }
    
    /**
     * Muestra un mensaje de alerta
     */
    function showAlert(message, type) {
        const alertContainer = document.getElementById('alert-container');
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.role = 'alert';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        `;
        
        alertContainer.innerHTML = '';
        alertContainer.appendChild(alertDiv);
        
        // Auto-cerrar después de 5 segundos
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
    
    /**
     * Valida formato de email
     */
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
});

/**
 * Integración con el SDK de Mercado Pago (para pagos directos)
 * Nota: Esta función es opcional y se usa para pagos con tarjeta directamente en el sitio
 */
class MercadoPagoCheckout {
    constructor(publicKey) {
        this.publicKey = publicKey;
        this.mp = null;
        this.initialized = false;
    }
    
    async init() {
        if (this.initialized) {
            return;
        }
        
        try {
            // Cargar SDK de Mercado Pago
            if (typeof MercadoPago === 'undefined') {
                await this.loadScript('https://sdk.mercadopago.com/js/v2');
            }
            
            this.mp = new MercadoPago(this.publicKey);
            this.initialized = true;
            
            console.log('Mercado Pago SDK inicializado correctamente');
        } catch (error) {
            console.error('Error al inicializar Mercado Pago SDK:', error);
        }
    }
    
    loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }
    
    async createCardForm(containerId) {
        if (!this.initialized) {
            await this.init();
        }
        
        const cardForm = this.mp.cardForm({
            amount: "100.5",
            iframe: true,
            form: {
                id: containerId,
                cardNumber: {
                    id: "form-checkout__cardNumber",
                    placeholder: "Número de tarjeta",
                },
                expirationDate: {
                    id: "form-checkout__expirationDate",
                    placeholder: "MM/YY",
                },
                securityCode: {
                    id: "form-checkout__securityCode",
                    placeholder: "CVV",
                },
                cardholderName: {
                    id: "form-checkout__cardholderName",
                    placeholder: "Titular de la tarjeta",
                },
                issuer: {
                    id: "form-checkout__issuer",
                    placeholder: "Banco emisor",
                },
                installments: {
                    id: "form-checkout__installments",
                    placeholder: "Cuotas",
                },
                identificationType: {
                    id: "form-checkout__identificationType",
                    placeholder: "Tipo de documento",
                },
                identificationNumber: {
                    id: "form-checkout__identificationNumber",
                    placeholder: "Número de documento",
                },
                cardholderEmail: {
                    id: "form-checkout__cardholderEmail",
                    placeholder: "E-mail",
                },
            },
            callbacks: {
                onFormMounted: error => {
                    if (error) {
                        console.warn("Form Mounted handling error: ", error);
                    } else {
                        console.log("Form mounted");
                    }
                },
                onSubmit: event => {
                    event.preventDefault();
                    
                    const {
                        paymentMethodId: payment_method_id,
                        issuerId: issuer_id,
                        cardholderEmail: email,
                        amount,
                        token,
                        installments,
                        identificationNumber,
                        identificationType,
                    } = cardForm.getCardFormData();
                    
                    // Aquí enviarías los datos al servidor
                    console.log('Payment data:', {
                        token,
                        payment_method_id,
                        issuer_id,
                        email,
                        amount,
                        installments,
                        identificationNumber,
                        identificationType
                    });
                },
                onFetching: (resource) => {
                    console.log("Fetching resource: ", resource);
                }
            },
        });
        
        return cardForm;
    }
}

// Exportar para uso global
window.MercadoPagoCheckout = MercadoPagoCheckout;
