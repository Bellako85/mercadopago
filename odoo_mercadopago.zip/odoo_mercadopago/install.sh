#!/bin/bash

# Script de instalación para Mercado Pago Payment Gateway - Odoo 17
# ===================================================================

echo "🚀 Instalando Mercado Pago Payment Gateway para Odoo 17"
echo "=========================================================="

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Banner
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║         MERCADO PAGO PAYMENT GATEWAY                   ║${NC}"
echo -e "${BLUE}║              para Odoo 17                              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# 1. Verificar Python
echo "📦 Verificando dependencias..."
echo ""

if ! command -v python3 &> /dev/null; then
    print_error "Python 3 no está instalado"
    exit 1
fi
PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
print_success "Python $PYTHON_VERSION encontrado"

# 2. Verificar pip
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 no está instalado"
    exit 1
fi
print_success "pip3 encontrado"

# 3. Instalar requests
echo ""
echo "📚 Instalando librería requests..."
pip3 install requests --quiet
if [ $? -eq 0 ]; then
    print_success "requests instalado correctamente"
else
    print_error "Error al instalar requests"
    exit 1
fi

# 4. Verificar estructura
echo ""
echo "🔍 Verificando estructura del módulo..."
echo ""

required_files=(
    "__init__.py"
    "__manifest__.py"
    "models/__init__.py"
    "models/mercadopago_config.py"
    "models/mercadopago_payment.py"
    "controllers/__init__.py"
    "controllers/mercadopago_controller.py"
    "views/mercadopago_config_view.xml"
    "views/mercadopago_payment_view.xml"
    "views/mercadopago_templates.xml"
    "views/mercadopago_menu.xml"
    "security/ir.model.access.csv"
    "data/ir_sequence_data.xml"
)

all_ok=true
for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        print_success "$file"
    else
        print_error "$file NO encontrado"
        all_ok=false
    fi
done

if [ "$all_ok" = false ]; then
    print_error "Algunos archivos necesarios no existen"
    exit 1
fi

# 5. Crear .env si no existe
echo ""
echo "⚙️  Configuración..."
echo ""

if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        print_warning ".env creado desde .env.example"
        print_info "Por favor configura tus credenciales en .env"
    else
        print_warning ".env.example no encontrado"
    fi
else
    print_success ".env ya existe"
fi

# 6. Verificar permisos
chmod +x install.sh 2>/dev/null
print_success "Permisos configurados"

# 7. Resumen
echo ""
echo "=================================================================="
echo -e "${GREEN}✨ INSTALACIÓN COMPLETADA${NC}"
echo "=================================================================="
echo ""
echo -e "${BLUE}📋 PRÓXIMOS PASOS:${NC}"
echo ""
echo "1️⃣  Reiniciar el servidor de Odoo:"
echo "   ${YELLOW}sudo systemctl restart odoo${NC}"
echo "   # O si usas el binario directamente:"
echo "   ${YELLOW}./odoo-bin -c /etc/odoo.conf${NC}"
echo ""
echo "2️⃣  Instalar el módulo en Odoo:"
echo "   - Ir a ${YELLOW}Aplicaciones${NC}"
echo "   - Click en ${YELLOW}'Actualizar lista de aplicaciones'${NC}"
echo "   - Buscar ${YELLOW}'Mercado Pago'${NC}"
echo "   - Click en ${YELLOW}'Instalar'${NC}"
echo ""
echo "3️⃣  Configurar Mercado Pago:"
echo "   - Ir a ${YELLOW}Mercado Pago > Configuración${NC}"
echo "   - Obtener credenciales en:"
echo "     ${BLUE}https://www.mercadopago.com.mx/developers/panel${NC}"
echo "   - Ingresar ${YELLOW}Public Key${NC} y ${YELLOW}Access Token${NC}"
echo "   - Activar ${YELLOW}'Modo de Prueba'${NC} para desarrollo"
echo ""
echo "4️⃣  Probar la integración:"
echo "   - Crear un pago en ${YELLOW}Mercado Pago > Pagos${NC}"
echo "   - O acceder al checkout: ${BLUE}/payment/mercadopago/checkout${NC}"
echo ""
echo -e "${BLUE}🧪 TARJETAS DE PRUEBA:${NC}"
echo "   Visa:       ${YELLOW}4509 9535 6623 3704${NC}"
echo "   Mastercard: ${YELLOW}5031 7557 3453 0604${NC}"
echo "   CVV:        ${YELLOW}123${NC}"
echo "   Fecha:      ${YELLOW}11/25${NC}"
echo ""
echo -e "${BLUE}📚 DOCUMENTACIÓN:${NC}"
echo "   - ${GREEN}README.md${NC}   - Guía completa"
echo "   - ${GREEN}EXAMPLES.md${NC} - Ejemplos de código"
echo "   - ${GREEN}FAQ.md${NC}      - Preguntas frecuentes"
echo ""
echo -e "${BLUE}🔗 RECURSOS:${NC}"
echo "   - Docs MP: ${BLUE}https://www.mercadopago.com.mx/developers${NC}"
echo "   - Panel:   ${BLUE}https://www.mercadopago.com.mx/developers/panel${NC}"
echo ""
echo -e "${GREEN}🎉 ¡Listo para usar!${NC}"
echo ""
