# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
import requests
import json
import logging

_logger = logging.getLogger(__name__)


class MercadoPagoPayment(models.Model):
    _name = 'mercadopago.payment'
    _description = 'Pago con Mercado Pago'
    _rec_name = 'reference'
    _order = 'create_date desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    # Información básica
    reference = fields.Char(string='Referencia', required=True, copy=False, readonly=True, default=lambda self: 'New')
    partner_id = fields.Many2one('res.partner', string='Cliente', required=True, tracking=True)
    company_id = fields.Many2one('res.company', string='Compañía', required=True, default=lambda self: self.env.company)
    
    
    # Información del pago
    amount = fields.Float(string='Monto', required=True, tracking=True)
    currency_id = fields.Many2one('res.currency', string='Moneda', required=True, default=lambda self: self.env.company.currency_id)
    description = fields.Text(string='Descripción')
    
    # Estado del pago
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('pending', 'Pendiente'),
        ('approved', 'Aprobado'),
        ('authorized', 'Autorizado'),
        ('in_process', 'En Proceso'),
        ('in_mediation', 'En Mediación'),
        ('rejected', 'Rechazado'),
        ('cancelled', 'Cancelado'),
        ('refunded', 'Reembolsado'),
        ('charged_back', 'Contracargo')
    ], string='Estado', default='draft', tracking=True, required=True)
    
    # Datos de Mercado Pago
    mp_payment_id = fields.Char(string='ID de Pago MP', readonly=True, copy=False, tracking=True)
    mp_preference_id = fields.Char(string='ID de Preferencia MP', readonly=True, copy=False)
    mp_init_point = fields.Char(string='URL de Pago MP', readonly=True, copy=False)
    mp_status = fields.Char(string='Estado MP', readonly=True)
    mp_status_detail = fields.Char(string='Detalle de Estado MP', readonly=True)
    
    # Información de la tarjeta/método de pago
    payment_method_id = fields.Char(string='Método de Pago')
    payment_type_id = fields.Char(string='Tipo de Pago')
    installments = fields.Integer(string='Cuotas', default=1)
    
    # Información del pagador
    payer_email = fields.Char(string='Email del Pagador')
    payer_identification_type = fields.Char(string='Tipo de Identificación')
    payer_identification_number = fields.Char(string='Número de Identificación')
    
    # Fechas
    payment_date = fields.Datetime(string='Fecha de Pago', readonly=True)
    date_approved = fields.Datetime(string='Fecha de Aprobación', readonly=True)
    
    # Respuesta completa de MP
    mp_response = fields.Text(string='Respuesta Completa MP', readonly=True)
    
    # Información adicional
    external_reference = fields.Char(string='Referencia Externa')
    notification_url = fields.Char(string='URL de Notificación')

    @api.model
    def create(self, vals):
        if vals.get('reference', 'New') == 'New':
            vals['reference'] = self.env['ir.sequence'].next_by_code('mercadopago.payment') or 'New'
        return super(MercadoPagoPayment, self).create(vals)

    def _get_mercadopago_config(self):
        """Obtiene la configuración de Mercado Pago"""
        config = self.env['mercadopago.config'].search([
            ('company_id', '=', self.company_id.id),
            ('active', '=', True)
        ], limit=1)
        
        if not config:
            raise UserError('No se encontró una configuración activa de Mercado Pago para esta compañía.')
        
        return config

    def action_create_preference(self):
        """Crea una preferencia de pago en Mercado Pago"""
        self.ensure_one()
        
        if self.state != 'draft':
            raise UserError('Solo se pueden crear preferencias para pagos en estado borrador.')
        
        config = self._get_mercadopago_config()
        
        # Preparar datos de la preferencia
        preference_data = self._prepare_preference_data(config)
        
        # Realizar petición a la API de Mercado Pago
        headers = {
            'Authorization': f'Bearer {config.access_token}',
            'Content-Type': 'application/json'
        }
        
        url = f'{config.get_base_url()}/checkout/preferences'
        
        try:
            response = requests.post(url, json=preference_data, headers=headers, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            
            # Guardar información de la preferencia
            self.write({
                'mp_preference_id': result.get('id'),
                'mp_init_point': result.get('init_point'),
                'state': 'pending',
                'mp_response': json.dumps(result, indent=2)
            })
            
            _logger.info(f'Preferencia de pago creada exitosamente: {result.get("id")}')
            
            return {
                'type': 'ir.actions.act_url',
                'url': result.get('init_point'),
                'target': 'new',
            }
            
        except requests.exceptions.RequestException as e:
            _logger.error(f'Error al crear preferencia de pago: {str(e)}')
            raise UserError(f'Error al comunicarse con Mercado Pago: {str(e)}')
        except Exception as e:
            _logger.error(f'Error inesperado: {str(e)}')
            raise UserError(f'Error inesperado: {str(e)}')

    def _prepare_preference_data(self, config):
        """Prepara los datos de la preferencia de pago"""
        self.ensure_one()
        
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        
        preference = {
            'items': [{
                'title': self.description or f'Pago - {self.reference}',
                'quantity': 1,
                'unit_price': float(self.amount),
                'currency_id': self.currency_id.name or 'MXN'
            }],
            'payer': {
                'name': self.partner_id.name,
                'email': self.partner_id.email or self.payer_email or 'cliente@ejemplo.com',
            },
            'back_urls': {
                'success': config.success_url or f'{base_url}/payment/mercadopago/success',
                'failure': config.failure_url or f'{base_url}/payment/mercadopago/failure',
                'pending': config.pending_url or f'{base_url}/payment/mercadopago/pending'
            },
            'auto_return': config.auto_return or 'approved',
            'external_reference': self.reference,
            'notification_url': config.webhook_url or f'{base_url}/payment/mercadopago/webhook',
            'statement_descriptor': config.statement_descriptor or 'PAGO OPTICA',
            'installments': config.installments or 12,
        }
        
        # Agregar información de identificación del pagador si está disponible
        if self.partner_id.vat:
            preference['payer']['identification'] = {
                'type': self.payer_identification_type or 'RFC',
                'number': self.partner_id.vat
            }
        
        return preference

    def action_check_payment_status(self):
        """Verifica el estado del pago en Mercado Pago"""
        self.ensure_one()
        
        if not self.mp_payment_id:
            raise UserError('No hay un ID de pago de Mercado Pago asociado.')
        
        config = self._get_mercadopago_config()
        
        headers = {
            'Authorization': f'Bearer {config.access_token}',
            'Content-Type': 'application/json'
        }
        
        url = f'{config.get_base_url()}/v1/payments/{self.mp_payment_id}'
        
        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            
            # Actualizar información del pago
            self._update_payment_from_mp_response(result)
            
            _logger.info(f'Estado del pago actualizado: {result.get("status")}')
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Estado del Pago',
                    'message': f'Estado actual: {self.state}',
                    'type': 'success' if self.state == 'approved' else 'info',
                    'sticky': False,
                }
            }
            
        except requests.exceptions.RequestException as e:
            _logger.error(f'Error al verificar estado del pago: {str(e)}')
            raise UserError(f'Error al comunicarse con Mercado Pago: {str(e)}')

    def _update_payment_from_mp_response(self, mp_data):
        """Actualiza el registro de pago con la respuesta de Mercado Pago"""
        self.ensure_one()
        
        state_mapping = {
            'pending': 'pending',
            'approved': 'approved',
            'authorized': 'authorized',
            'in_process': 'in_process',
            'in_mediation': 'in_mediation',
            'rejected': 'rejected',
            'cancelled': 'cancelled',
            'refunded': 'refunded',
            'charged_back': 'charged_back'
        }
        
        values = {
            'mp_payment_id': mp_data.get('id'),
            'mp_status': mp_data.get('status'),
            'mp_status_detail': mp_data.get('status_detail'),
            'state': state_mapping.get(mp_data.get('status'), 'pending'),
            'payment_method_id': mp_data.get('payment_method_id'),
            'payment_type_id': mp_data.get('payment_type_id'),
            'installments': mp_data.get('installments', 1),
            'mp_response': json.dumps(mp_data, indent=2)
        }
        
        # Información del pagador
        if mp_data.get('payer'):
            payer = mp_data['payer']
            values.update({
                'payer_email': payer.get('email'),
            })
            if payer.get('identification'):
                values.update({
                    'payer_identification_type': payer['identification'].get('type'),
                    'payer_identification_number': payer['identification'].get('number'),
                })
        
        # Fechas
        if mp_data.get('date_created'):
            values['payment_date'] = mp_data['date_created']
        
        if mp_data.get('date_approved'):
            values['date_approved'] = mp_data['date_approved']
        
        self.write(values)

    def action_refund_payment(self):
        """Reembolsa un pago aprobado"""
        self.ensure_one()
        
        if self.state != 'approved':
            raise UserError('Solo se pueden reembolsar pagos aprobados.')
        
        if not self.mp_payment_id:
            raise UserError('No hay un ID de pago de Mercado Pago asociado.')
        
        config = self._get_mercadopago_config()
        
        headers = {
            'Authorization': f'Bearer {config.access_token}',
            'Content-Type': 'application/json'
        }
        
        url = f'{config.get_base_url()}/v1/payments/{self.mp_payment_id}/refunds'
        
        try:
            response = requests.post(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            
            self.write({
                'state': 'refunded',
                'mp_response': json.dumps(result, indent=2)
            })
            
            _logger.info(f'Pago reembolsado exitosamente: {self.mp_payment_id}')
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Reembolso Exitoso',
                    'message': 'El pago ha sido reembolsado correctamente.',
                    'type': 'success',
                    'sticky': False,
                }
            }
            
        except requests.exceptions.RequestException as e:
            _logger.error(f'Error al reembolsar pago: {str(e)}')
            raise UserError(f'Error al comunicarse con Mercado Pago: {str(e)}')

    def action_cancel_payment(self):
        """Cancela un pago"""
        self.ensure_one()
        
        if self.state in ['approved', 'refunded', 'cancelled']:
            raise UserError('No se puede cancelar un pago en este estado.')
        
        self.write({'state': 'cancelled'})
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Pago Cancelado',
                'message': 'El pago ha sido cancelado.',
                'type': 'warning',
                'sticky': False,
            }
        }

    def action_open_mp_payment(self):
        """Abre el enlace de pago de Mercado Pago"""
        self.ensure_one()
        
        if not self.mp_init_point:
            return self.action_create_preference()
        
        return {
            'type': 'ir.actions.act_url',
            'url': self.mp_init_point,
            'target': 'new',
        }


class MercadoPagoPaymentTransaction(models.Model):
    _name = 'mercadopago.payment.transaction'
    _description = 'Transacción de Pago Mercado Pago'
    _order = 'create_date desc'

    payment_id = fields.Many2one('mercadopago.payment', string='Pago', required=True, ondelete='cascade')
    transaction_type = fields.Selection([
        ('payment', 'Pago'),
        ('refund', 'Reembolso'),
        ('chargeback', 'Contracargo'),
        ('notification', 'Notificación')
    ], string='Tipo de Transacción', required=True)
    mp_transaction_id = fields.Char(string='ID de Transacción MP')
    status = fields.Char(string='Estado')
    amount = fields.Float(string='Monto')
    transaction_data = fields.Text(string='Datos de Transacción')
    create_date = fields.Datetime(string='Fecha de Creación', readonly=True)
