# -*- coding: utf-8 -*-
from . import mercadopago_config
from . import mercadopago_payment
