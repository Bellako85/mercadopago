# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class MercadoPagoConfig(models.Model):
    _name = 'mercadopago.config'
    _description = 'Configuración de Mercado Pago'
    _rec_name = 'company_id'

    company_id = fields.Many2one('res.company', string='Compañía', required=True, default=lambda self: self.env.company)
    
    # Credenciales de Mercado Pago
    public_key = fields.Char(string='Public Key', required=True, help='Clave pública de Mercado Pago')
    access_token = fields.Char(string='Access Token', required=True, help='Token de acceso de Mercado Pago')
    
    # Configuración del entorno
    is_test_mode = fields.Boolean(string='Modo de Prueba', default=True, help='Activar para usar credenciales de prueba')
    
    # URLs de webhook
    webhook_url = fields.Char(string='URL de Webhook', help='URL para recibir notificaciones de pago')
    
    # Configuración adicional
    statement_descriptor = fields.Char(string='Descriptor de Estado de Cuenta', help='Nombre que aparecerá en el estado de cuenta del cliente')
    installments = fields.Integer(string='Número Máximo de Cuotas', default=12, help='Número máximo de cuotas permitidas')
    auto_return = fields.Selection([
        ('approved', 'Solo Aprobados'),
        ('all', 'Todos')
    ], string='Retorno Automático', default='approved', help='Configuración de retorno automático después del pago')
    
    # URLs de retorno
    success_url = fields.Char(string='URL de Éxito', help='URL de redirección en caso de pago exitoso')
    failure_url = fields.Char(string='URL de Fallo', help='URL de redirección en caso de pago fallido')
    pending_url = fields.Char(string='URL de Pendiente', help='URL de redirección para pagos pendientes')
    
    # Estado
    active = fields.Boolean(string='Activo', default=True)

    _sql_constraints = [
        ('company_unique', 'unique(company_id)', 'Ya existe una configuración de Mercado Pago para esta compañía.')
    ]

    @api.constrains('installments')
    def _check_installments(self):
        for record in self:
            if record.installments < 1 or record.installments > 24:
                raise ValidationError('El número de cuotas debe estar entre 1 y 24.')

    def get_base_url(self):
        """Retorna la URL base según el modo (test/producción)"""
        self.ensure_one()
        if self.is_test_mode:
            return 'https://api.mercadopago.com'
        return 'https://api.mercadopago.com'

    def get_credentials(self):
        """Retorna las credenciales de Mercado Pago"""
        self.ensure_one()
        return {
            'public_key': self.public_key,
            'access_token': self.access_token,
            'is_test_mode': self.is_test_mode
        }
