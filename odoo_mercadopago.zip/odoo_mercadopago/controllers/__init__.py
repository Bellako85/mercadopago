# -*- coding: utf-8 -*-
from . import mercadopago_controller
