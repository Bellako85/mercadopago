# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json
import logging

_logger = logging.getLogger(__name__)


class MercadoPagoController(http.Controller):

    @http.route('/payment/mercadopago/create', type='json', auth='user', methods=['POST'], csrf=False)
    def create_payment(self, **kwargs):
        """Crea un pago con Mercado Pago"""
        try:
            # Obtener datos del request
            partner_id = kwargs.get('partner_id')
            amount = kwargs.get('amount')
            description = kwargs.get('description', '')
            
            if not partner_id or not amount:
                return {'error': 'Faltan datos requeridos: partner_id y amount'}
            
            # Crear el registro de pago
            payment = request.env['mercadopago.payment'].create({
                'partner_id': partner_id,
                'amount': amount,
                'description': description,
                'state': 'draft'
            })
            
            # Crear preferencia en Mercado Pago
            result = payment.action_create_preference()
            
            return {
                'success': True,
                'payment_id': payment.id,
                'reference': payment.reference,
                'mp_preference_id': payment.mp_preference_id,
                'init_point': payment.mp_init_point
            }
            
        except Exception as e:
            _logger.error(f'Error al crear pago: {str(e)}')
            return {'error': str(e)}

    @http.route('/payment/mercadopago/webhook', type='json', auth='none', methods=['POST'], csrf=False)
    def mercadopago_webhook(self, **kwargs):
        """Webhook para recibir notificaciones de Mercado Pago"""
        try:
            # Mercado Pago envía notificaciones en formato JSON
            data = json.loads(request.httprequest.data.decode('utf-8'))
            
            _logger.info(f'Webhook recibido de Mercado Pago: {json.dumps(data, indent=2)}')
            
            # Tipo de notificación
            notification_type = data.get('type') or data.get('topic')
            
            if notification_type == 'payment':
                payment_id = data.get('data', {}).get('id')
                if payment_id:
                    self._process_payment_notification(payment_id)
            
            return {'status': 'ok'}
            
        except Exception as e:
            _logger.error(f'Error procesando webhook: {str(e)}')
            return {'status': 'error', 'message': str(e)}

    def _process_payment_notification(self, mp_payment_id):
        """Procesa la notificación de un pago"""
        try:
            # Buscar el pago por mp_payment_id
            payment = request.env['mercadopago.payment'].sudo().search([
                ('mp_payment_id', '=', str(mp_payment_id))
            ], limit=1)
            
            if payment:
                # Actualizar el estado del pago
                payment.action_check_payment_status()
                _logger.info(f'Pago actualizado desde webhook: {payment.reference}')
            else:
                _logger.warning(f'No se encontró pago con mp_payment_id: {mp_payment_id}')
                
        except Exception as e:
            _logger.error(f'Error procesando notificación de pago: {str(e)}')

    @http.route('/payment/mercadopago/success', type='http', auth='public', methods=['GET'], website=True)
    def payment_success(self, **kwargs):
        """Página de éxito después del pago"""
        try:
            # Obtener parámetros de Mercado Pago
            payment_id = kwargs.get('payment_id')
            status = kwargs.get('status')
            external_reference = kwargs.get('external_reference')
            preference_id = kwargs.get('preference_id')
            
            _logger.info(f'Redirección de éxito - Payment ID: {payment_id}, Status: {status}')
            
            # Buscar el pago
            payment = None
            if external_reference:
                payment = request.env['mercadopago.payment'].sudo().search([
                    ('reference', '=', external_reference)
                ], limit=1)
            elif preference_id:
                payment = request.env['mercadopago.payment'].sudo().search([
                    ('mp_preference_id', '=', preference_id)
                ], limit=1)
            
            if payment and payment_id:
                # Actualizar el pago con el ID de Mercado Pago
                payment.sudo().write({'mp_payment_id': payment_id})
                payment.sudo().action_check_payment_status()
            
            return request.render('odoo_mercadopago.payment_success_template', {
                'payment': payment,
                'status': status,
                'payment_id': payment_id
            })
            
        except Exception as e:
            _logger.error(f'Error en página de éxito: {str(e)}')
            return request.render('odoo_mercadopago.payment_error_template', {
                'error_message': str(e)
            })

    @http.route('/payment/mercadopago/failure', type='http', auth='public', methods=['GET'], website=True)
    def payment_failure(self, **kwargs):
        """Página de fallo después del pago"""
        try:
            payment_id = kwargs.get('payment_id')
            status = kwargs.get('status')
            external_reference = kwargs.get('external_reference')
            
            _logger.warning(f'Redirección de fallo - Payment ID: {payment_id}, Status: {status}')
            
            # Buscar el pago
            payment = None
            if external_reference:
                payment = request.env['mercadopago.payment'].sudo().search([
                    ('reference', '=', external_reference)
                ], limit=1)
            
            if payment and payment_id:
                payment.sudo().write({
                    'mp_payment_id': payment_id,
                    'state': 'rejected'
                })
            
            return request.render('odoo_mercadopago.payment_failure_template', {
                'payment': payment,
                'status': status,
                'payment_id': payment_id
            })
            
        except Exception as e:
            _logger.error(f'Error en página de fallo: {str(e)}')
            return request.render('odoo_mercadopago.payment_error_template', {
                'error_message': str(e)
            })

    @http.route('/payment/mercadopago/pending', type='http', auth='public', methods=['GET'], website=True)
    def payment_pending(self, **kwargs):
        """Página de pago pendiente"""
        try:
            payment_id = kwargs.get('payment_id')
            status = kwargs.get('status')
            external_reference = kwargs.get('external_reference')
            
            _logger.info(f'Redirección de pendiente - Payment ID: {payment_id}, Status: {status}')
            
            # Buscar el pago
            payment = None
            if external_reference:
                payment = request.env['mercadopago.payment'].sudo().search([
                    ('reference', '=', external_reference)
                ], limit=1)
            
            if payment and payment_id:
                payment.sudo().write({
                    'mp_payment_id': payment_id,
                    'state': 'pending'
                })
            
            return request.render('odoo_mercadopago.payment_pending_template', {
                'payment': payment,
                'status': status,
                'payment_id': payment_id
            })
            
        except Exception as e:
            _logger.error(f'Error en página de pendiente: {str(e)}')
            return request.render('odoo_mercadopago.payment_error_template', {
                'error_message': str(e)
            })

    @http.route('/payment/mercadopago/status/<int:payment_id>', type='json', auth='user', methods=['POST'])
    def check_payment_status(self, payment_id, **kwargs):
        """Verifica el estado de un pago"""
        try:
            payment = request.env['mercadopago.payment'].browse(payment_id)
            
            if not payment.exists():
                return {'error': 'Pago no encontrado'}
            
            payment.action_check_payment_status()
            
            return {
                'success': True,
                'payment_id': payment.id,
                'reference': payment.reference,
                'state': payment.state,
                'mp_status': payment.mp_status,
                'mp_status_detail': payment.mp_status_detail,
                'amount': payment.amount
            }
            
        except Exception as e:
            _logger.error(f'Error verificando estado del pago: {str(e)}')
            return {'error': str(e)}

    @http.route('/payment/mercadopago/checkout', type='http', auth='user', methods=['GET'], website=True)
    def checkout_page(self, **kwargs):
        """Página de checkout con Mercado Pago"""
        try:
            # Obtener configuración de Mercado Pago
            config = request.env['mercadopago.config'].sudo().search([
                ('company_id', '=', request.env.company.id),
                ('active', '=', True)
            ], limit=1)
            
            if not config:
                return request.render('odoo_mercadopago.payment_error_template', {
                    'error_message': 'No se encontró configuración de Mercado Pago'
                })
            
            return request.render('odoo_mercadopago.checkout_template', {
                'config': config,
                'partner': request.env.user.partner_id
            })
            
        except Exception as e:
            _logger.error(f'Error en página de checkout: {str(e)}')
            return request.render('odoo_mercadopago.payment_error_template', {
                'error_message': str(e)
            })
